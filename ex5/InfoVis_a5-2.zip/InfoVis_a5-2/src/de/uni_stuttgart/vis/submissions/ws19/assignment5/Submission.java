package de.uni_stuttgart.vis.submissions.ws19.assignment5;

import java.awt.Color;
import java.util.LinkedList;
import java.util.List;
import java.util.Random;

import de.uni_stuttgart.vis.data.ws19.assignment5.*;
import de.uni_stuttgart.vis.framework.InfoVisFramework;
import de.uni_stuttgart.vis.geom.AbstractGeometry;
import de.uni_stuttgart.vis.geom.Rectangle;


public class Submission extends InfoVisFramework {

	@Override
	public List<AbstractGeometry> mapData() {
		// TODO Auto-generated method stub
		return null;		
	}

	public static void main(String[] args) {
		new Submission();

	}
	

}
