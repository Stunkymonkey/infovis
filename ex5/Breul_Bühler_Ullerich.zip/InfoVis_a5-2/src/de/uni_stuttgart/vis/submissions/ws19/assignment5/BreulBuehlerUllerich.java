package de.uni_stuttgart.vis.submissions.ws19.assignment5;

import java.awt.Color;
import java.awt.Font;
import java.util.LinkedList;
import java.util.List;
import java.util.Random;

import de.uni_stuttgart.vis.data.ws19.assignment5.*;
import de.uni_stuttgart.vis.framework.InfoVisFramework;
import de.uni_stuttgart.vis.geom.AbstractGeometry;
import de.uni_stuttgart.vis.geom.Rectangle;


public class BreulBuehlerUllerich extends InfoVisFramework {
	
	private int width;
	private int height;

	@Override
	public List<AbstractGeometry> mapData() {
		Tree tree = new DataProvider().getTree();
		width = InfoVisFramework.defaultScreenWidth;
		height = InfoVisFramework.defaultScreenHeight;
		
		LinkedList<AbstractGeometry> list = new LinkedList<AbstractGeometry>();
		Rectangle rect = new Rectangle(0, 0, width, height);
		rect.setColor(getRandomColor());
		list.add(rect);
		
		return recursiveIteration(list, tree.getRoot(), 1, 0, 0, width, height);
	}
	
	public void draw(List<AbstractGeometry> geometryList) {
        this.renderCanvas(geometryList);
    }
	
	private List<AbstractGeometry> recursiveIteration(List<AbstractGeometry> list, TreeNode current_node, int depth, int x_min, int y_min, int x_max, int y_max){
		boolean draw_in_x_dir = true;
		if (x_max - x_min < y_max -y_min) {
			draw_in_x_dir = false;
		}
		int sum = 0;
		for (TreeNode node: current_node.getChildren()) {
			sum += node.getWeight();
		}
		int drawn = 0;
		for (TreeNode node: current_node.getChildren()) {
			float percentage =  node.getWeight() / (float) sum;
			int draw_pixels;
			if (draw_in_x_dir) {
				draw_pixels = (int) ((float)(x_max - x_min) * percentage);
			} else {
				draw_pixels = (int) ((float)(y_max - y_min) * percentage);
			}

			int minimum, maximum;
			int padding = 10 * depth;
			Rectangle rect;
			if (draw_in_x_dir) {
				minimum = x_min + drawn;
				maximum = x_min + drawn + draw_pixels;
				rect = new Rectangle(minimum + padding, y_min + padding, maximum - minimum - (2 * padding), y_max - y_min - (2 * padding));
			} else {
				minimum = y_min + drawn;
				maximum = y_min + drawn + draw_pixels;
				rect = new Rectangle(x_min + padding, minimum + padding, x_max - x_min - (2 * padding), maximum - minimum - (2 * padding));
			}
			rect.setColor(getRandomColor());
//			rect.setText(node.getContent());
//			rect.setFont(new Font("Times New Roman",0, 26));
			drawn += draw_pixels;

			list.add(rect);
			if (draw_in_x_dir) {
				list = recursiveIteration(list, node, depth + 1, minimum, y_min, maximum, y_max);
			} else {
				list = recursiveIteration(list, node, depth + 1, x_min, minimum, x_max, maximum);
			}
		}
		return list;
	}
	
	private Color getRandomColor() {
		Random rand = new Random();
		float r = rand.nextFloat();
		float g = rand.nextFloat();
		float b = rand.nextFloat();
		return new Color(r, g, b);
	}

	public static void main(String[] args) {
		new BreulBuehlerUllerich();
	}
}
