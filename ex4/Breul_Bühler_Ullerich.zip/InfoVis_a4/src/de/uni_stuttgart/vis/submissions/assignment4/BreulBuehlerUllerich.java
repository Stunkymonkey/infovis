package de.uni_stuttgart.vis.submissions.assignment4;

import java.util.List;

import de.uni_stuttgart.vis.data.Vector2D;
import de.uni_stuttgart.vis.data.assignment4.DataProvider;
import de.uni_stuttgart.vis.data.assignment4.FdlHelper;
import de.uni_stuttgart.vis.data.assignment4.Graph;
import de.uni_stuttgart.vis.data.assignment4.GraphNode;
import de.uni_stuttgart.vis.framework.InfoVisFramework;
import de.uni_stuttgart.vis.geom.AbstractGeometry;


public class BreulBuehlerUllerich extends InfoVisFramework {

	@Override
	public List<AbstractGeometry> mapData() {
		// TODO Auto-generated method stub
		double l = FdlHelper.height;
		double w = FdlHelper.width;
		Graph g = new DataProvider().getGraph();
		double t = 5;
		
		FdlHelper fdl = new FdlHelper(g.getNodes());
		List<AbstractGeometry> result = fdl.getGraphGeometry(g);
		renderCanvas(result);
		try {
			Thread.sleep(3000);
		} catch (InterruptedException e1) {
			e1.printStackTrace();
		}

		for (int i = 0; i < FdlHelper.iterations; i++) {
			Vector2D[] disp = new Vector2D[g.getNodes().size()];
			for (GraphNode v : g.getNodes()) {
				disp[v.getNodeID() - 1] = new Vector2D(0.0, 0.0);
				for (GraphNode u : g.getNodes()) {
					if (u!= v) {
						Vector2D delta = v.getPosition().subtract(u.getPosition());
						disp[v.getNodeID() - 1] = disp[v.getNodeID() - 1].add(delta.normalize().multiply(fdl.fr(delta.norm())));
					}
				}
			}
			
			for (GraphNode v : g.getNodes()) {
				for (GraphNode u: v.getAdjacentNodes()) {
					Vector2D delta = v.getPosition().subtract(u.getPosition());
					disp[v.getNodeID() - 1] = disp[v.getNodeID() - 1].subtract(delta.normalize().multiply(fdl.fa(delta.norm())));
					disp[u.getNodeID() - 1] = disp[u.getNodeID() - 1].add(delta.normalize().multiply(fdl.fa(delta.norm())));
				}
			}
			
			for (GraphNode v: g.getNodes()) {
				v.setPosition(v.getPosition().add(disp[v.getNodeID() - 1].normalize().multiply(Math.min(disp[v.getNodeID() - 1].norm(), t))));
				v.getPosition().setX(Math.min(w, Math.max(0.0, v.getPosition().getX())));
				v.getPosition().setY(Math.min(l, Math.max(0.0, v.getPosition().getY())));
			}

			t = fdl.cool((int) t);
			try {
				Thread.sleep(250);
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
			result = fdl.getGraphGeometry(g);
			renderCanvas(result);
		}
		return result;
	}

	public static void main(String[] args) {
		new BreulBuehlerUllerich();
	}
}
