package de.uni_stuttgart.vis.submissions.assignment4;

import java.util.List;


import de.uni_stuttgart.vis.framework.InfoVisFramework;
import de.uni_stuttgart.vis.geom.AbstractGeometry;


public class Submission extends InfoVisFramework {

	@Override
	public List<AbstractGeometry> mapData() {
		// TODO Auto-generated method stub
		return null;
	}

	public static void main(String[] args) {
		new Submission();

	}
}
