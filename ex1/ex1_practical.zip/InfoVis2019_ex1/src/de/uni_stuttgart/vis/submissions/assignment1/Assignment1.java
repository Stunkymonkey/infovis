package de.uni_stuttgart.vis.submissions.assignment1;

import java.util.List;

import java.awt.Color;
import java.awt.Font;

import de.uni_stuttgart.vis.framework.InfoVisFramework;
import de.uni_stuttgart.vis.geom.AbstractGeometry;
import de.uni_stuttgart.vis.geom.Rectangle;
import de.uni_stuttgart.vis.helper.StringHelper;
import de.uni_stuttgart.vis.data.WeightedString;
import de.uni_stuttgart.vis.data.wordCloud.DataProvider;

// TODO rename class to match your last names
public class Assignment1 extends InfoVisFramework {

	@Override
	public List<AbstractGeometry> mapData() {
		DataProvider dataProvider = new DataProvider();
		List<WeightedString> strings = dataProvider.getWords();
		
		// TODO create tag cloud here
		return null;
	}

	public static void main(String[] args) {
		new Assignment1();
	}

}
