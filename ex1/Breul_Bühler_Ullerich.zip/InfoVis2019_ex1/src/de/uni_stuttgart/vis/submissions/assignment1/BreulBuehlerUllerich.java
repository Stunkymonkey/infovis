package de.uni_stuttgart.vis.submissions.assignment1;

import java.util.ArrayList;
import java.util.List;

import java.awt.Color;
import java.awt.Font;
import java.awt.Point;

import de.uni_stuttgart.vis.framework.InfoVisFramework;
import de.uni_stuttgart.vis.geom.AbstractGeometry;
import de.uni_stuttgart.vis.geom.Rectangle;
import de.uni_stuttgart.vis.helper.StringHelper;
import de.uni_stuttgart.vis.data.WeightedString;
import de.uni_stuttgart.vis.data.wordCloud.DataProvider;

public class BreulBuehlerUllerich extends InfoVisFramework {

	@Override
	public List<AbstractGeometry> mapData() {
		DataProvider dataProvider = new DataProvider();
		List<WeightedString> strings = dataProvider.getWords();

		strings.sort((s1, s2) -> s2.compareTo(s1));

		float r = 1000.f;
		int m_max = 500;
		float c = 5.f;
		float d = -1.f;

		double x[] = new double[m_max];
		double y[] = new double[m_max];
		Rectangle boxes[] = new Rectangle[strings.size()];

		for (int m = 0; m < m_max; m++) {
			float scur = (float) m / (float) m_max;
			x[m] = (d * Math.cos(2.0 * Math.PI * Math.sqrt(scur) * c)) * scur * r;
			y[m] = (Math.sin(2.0 * Math.PI * Math.sqrt(scur) * c)) * scur * r;
		}

		int index = 0;
		List<AbstractGeometry> result = new ArrayList<AbstractGeometry>();
		for (int i = 0; i < strings.size(); i++) {
			WeightedString s = strings.get(i);
			int size = s.getFrequency();
			java.awt.Font f = new java.awt.Font("Helvetica", Font.PLAIN, (size / 5) + 12);
			Color color = getColor(dataProvider.getSentiment(s.getText()));

			java.awt.Rectangle boundingBox = StringHelper.getStringSize(s.getText(), f);
			if (i > 0) {
				while (true) {
					if (!checkPrevPoints(x[index], y[index], boundingBox.width, boundingBox.height, boxes)) {
						index += 1;
					} else {
						break;
					}
				}
			}
			Rectangle bak = new Rectangle((int) x[index], (int) y[index], boundingBox.width, boundingBox.height);
			boxes[i] = bak;
			Rectangle tmp = new Rectangle((int) x[index] + 400, (int) y[index] + 500, boundingBox.width, boundingBox.height);
			tmp.setText(s.getText());
			tmp.setColor(new Color(255, 255, 255));
			tmp.setTextColor(color);
			tmp.setFont(f);
			result.add(tmp);
		}
		return result;
	}

	public static void main(String[] args) {
		new BreulBuehlerUllerich();
	}

	private Color getColor(float sentiment) {
		if (sentiment > 0) {
			return new Color(0, (int) (sentiment * 255), 0);
		} else {
			return new Color((int) (sentiment * -255), 0, 0);
		}
	}

	private boolean checkPrevPoints(double x_min, double y_min, double width, double height, Rectangle[] rects) {
		java.awt.Rectangle new_rect = new java.awt.Rectangle((int) x_min, (int) y_min, (int) width, (int) height);
		for (Rectangle r : rects) {
			if (r != null) {
				java.awt.Rectangle tmp = r.getRect();
				if (tmp.intersects(new_rect)) {
					return false;
				}
			}
		}
		return true;
	}
}
