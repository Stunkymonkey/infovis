package de.uni_stuttgart.vis.submissions.ws19.assignment10;
import java.awt.Color;
import java.awt.Font;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;

import de.uni_stuttgart.vis.data.ws19.assignment10.*;
import de.uni_stuttgart.vis.framework.InfoVisFramework;
import de.uni_stuttgart.vis.geom.AbstractGeometry;
import de.uni_stuttgart.vis.geom.Rectangle;


public class Submission extends InfoVisFramework {

	@Override
	public List<AbstractGeometry> mapData() {
		ArrayList<AbstractGeometry> geometry = new ArrayList<AbstractGeometry>();
		DataProvider data = new DataProvider();
		int n_documents = data.getNumberOfDocuments();
		ArrayList<String> words = data.getWords();
		HashMap<String, Float> term_freq = new HashMap<String, Float>();
		for(String word : words) {
			Float count = term_freq.containsKey(word) ? term_freq.get(word) : 0.f;
			term_freq.put(word, count + 1.f);
		}
		System.out.println(getTop(term_freq, 20));
	    
	    HashMap<String, Float> tfidf = new HashMap<String, Float>();
	    for(String word : words) {
	    	Float freq = term_freq.get(word);
	    	int doc_freq = data.getDocumentFrequency(word);
	    	Float tfidf_score = (float) (freq * Math.log(((float) n_documents) / ((float) doc_freq)));
	    	tfidf.put(word, tfidf_score);
	    }
	    List<Entry<String, Float>> top_tfidf = getTop(tfidf, 20);
	    System.out.println(top_tfidf);
	    
	    int x = 0;
	    int y = 20;
	    for (Entry<String, Float> entry: top_tfidf) {
	    	Rectangle tmp = new Rectangle((int) x, y, 250, 50);
	    	tmp.setText(entry.getKey());
	    	//
	    	java.awt.Font f = new java.awt.Font("Helvetica", Font.PLAIN, (int) Math.sqrt(entry.getValue()) * 10);
	    	tmp.setFont(f);
	    	tmp.setColor(new Color(255, 255, 255));
	    	geometry.add(tmp);
		    
		    x += 250;
		    if (x > 1000) {
		    	y = y + 50;
		    }
		    x %= 1250;
	    }
		
		return geometry;		
	}
	
	private List<Entry<String, Float>> getTop(HashMap<String, Float> hashmap, int amount) {
		Set<Entry<String, Float>> set = hashmap.entrySet();
	    List<Entry<String, Float>> list = new ArrayList<Entry<String, Float>>(set);
	    Collections.sort(list, new Comparator<Map.Entry<String, Float>>() {
	        @Override
	        public int compare(Entry<String, Float> o1,
	                Entry<String, Float> o2) {
	            return o2.getValue().compareTo(o1.getValue());
	        }
	    });
	    return list.subList(0, amount);
	}
	

	public static void main(String[] args) {
		new Submission();
	}
}
