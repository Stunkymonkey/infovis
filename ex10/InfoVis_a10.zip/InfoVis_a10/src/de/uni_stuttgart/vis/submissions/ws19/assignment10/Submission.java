package de.uni_stuttgart.vis.submissions.ws19.assignment10;
import java.util.ArrayList;
import java.util.List;
import de.uni_stuttgart.vis.data.ws19.assignment10.*;
import de.uni_stuttgart.vis.framework.InfoVisFramework;
import de.uni_stuttgart.vis.geom.AbstractGeometry;
import de.uni_stuttgart.vis.geom.Rectangle;


public class Submission extends InfoVisFramework {

	@Override
	public List<AbstractGeometry> mapData() {
		ArrayList<AbstractGeometry> geometry = new ArrayList<AbstractGeometry>();
		// TODO Auto-generated method stub
		
		return geometry;		
	}
	

	public static void main(String[] args) {
		new Submission();

	}
	

}
